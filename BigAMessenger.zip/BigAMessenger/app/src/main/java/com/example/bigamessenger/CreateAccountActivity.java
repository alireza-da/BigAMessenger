package com.example.bigamessenger;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.dd.processbutton.ProcessButton;
import com.dd.processbutton.iml.ActionProcessButton;
import com.dd.processbutton.iml.GenerateProcessButton;
import com.parse.LogInCallback;
import com.parse.ParseException;
import com.parse.ParseObject;
import com.parse.ParseUser;
import com.parse.SignUpCallback;

import buttonConfigurations.ProgressGenerator;
import model.User;

public class CreateAccountActivity extends AppCompatActivity implements ProgressGenerator.OnCompleteListener {
    private EditText userNameField, passwordField, emailField;
    private ProgressGenerator progressGenerator;
    private Button createAccountButton;
    private TextView loginLink;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_account);
        progressGenerator = new ProgressGenerator(this);
        createAccountButton = findViewById(R.id.create_account_btn);
        emailField = findViewById(R.id.user_email_field);
        userNameField = findViewById(R.id.username_field);
        passwordField = findViewById(R.id.password_field);
        loginLink = findViewById(R.id.login_link);
        createAccountButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //create user and send to database
                final String email = emailField.getText().toString();
                final String username = userNameField.getText().toString();
                final String password = passwordField.getText().toString();
                if (username.isEmpty() || email.isEmpty() || password.isEmpty()){
                    final AlertDialog.Builder emptyAlert = new AlertDialog.Builder(CreateAccountActivity.this);
                    emptyAlert.setTitle("Empty Error");
                    emptyAlert.setMessage("Fill all field in order to complete the validation and submission.");
                    emptyAlert.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    });
                    emptyAlert.show();
                }
                else {
                    final User user = new User();
                    user.setUsername(username);
                    user.setEmail(email);
                    user.setPassword(password);

                    //set custom property
                    user.signUpInBackground(new SignUpCallback() {
                        @Override
                        public void done(ParseException e) {
                            if ( e == null){
                                createAccountButton.setEnabled(false);
                                emailField.setEnabled(false);
                                passwordField.setEnabled(false);
                                userNameField.setEnabled(false);
                                logInUser(user,password);
                                //Toast.makeText(getApplicationContext(), "Signed up successfully",Toast.LENGTH_SHORT).show();
                            }
                            else {
                                Log.e("USER", "SIGN UP ERROR");
                                Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_LONG).show();
                                e.printStackTrace();
                            }
                        }
                    });
                }
            }
        });
        loginLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
                startActivity(new Intent(CreateAccountActivity.this, MainActivity.class));
            }
        });
    }

    private void logInUser(ParseUser user, String password) {
        if (!user.getUsername().isEmpty() && !password.isEmpty()){
            ParseUser.logInInBackground(user.getUsername(), password, new LogInCallback() {
                @Override
                public void done(ParseUser user, ParseException e) {
                    if (e == null){
                        Log.v("USER", user.getUsername()+" Connected");
                        finish();
                        startActivity(new Intent(CreateAccountActivity.this, ChatActivity.class));
                    }
                    else {
                        Log.e("USER", "SIGN IN ERROR");
                        Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_LONG).show();
                        e.printStackTrace();
                    }
                }
            });
        }
    }

    @Override
    public void onComplete() { // after registration is done
        finish();
        startActivity(new Intent(CreateAccountActivity.this, ChatActivity.class));
    }
}