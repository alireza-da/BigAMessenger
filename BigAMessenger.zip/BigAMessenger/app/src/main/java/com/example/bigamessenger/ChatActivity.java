package com.example.bigamessenger;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.parse.FindCallback;
import com.parse.LogOutCallback;
import com.parse.ParseException;
import com.parse.ParseQuery;
import com.parse.ParseUser;
import com.parse.SaveCallback;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

import buttonConfigurations.ProgressGenerator;
import data.ChatListAdaptor;
import model.Message;

public class ChatActivity extends AppCompatActivity {
    private int notificationId = 0;
    private boolean newMessages;
    private static final String CHANNEL_ID = "BIGA"+ParseUser.getCurrentUser().getUsername()+ParseUser.getCurrentUser().getObjectId();
    private EditText messageField;
    private Button sendButton;
    private ProgressGenerator progressGenerator;
    private static String USER_ID = "userId";
    private String currentUserId;
    private String currentUsername;
    private ListView chatListView;
    private ArrayList<Message> messageArrayList;
    private ChatListAdaptor chatListAdaptor;
    private Handler handler = new Handler();
    private static final int MAX_CHAT_MESSAGES_TO_SHOW = 70;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);
        getCurrentUser();
        handler.postDelayed(runnable, 100);

    }

    Runnable runnable = new Runnable() {
        @Override
        public void run() {
            int size = messageArrayList.size();
            refreshChats();
            if (messageArrayList.size() > size){
                sendNotification("Big A Reporting","You have "+(messageArrayList.size() - size)+" Messages");
            }
            handler.postDelayed(this, 100);
        }
    };

    private void getCurrentUser() {
        currentUserId = ParseUser.getCurrentUser().getObjectId();
        currentUsername = ParseUser.getCurrentUser().getUsername();
        messagePosting();
    }

    private void messagePosting() {
        messageField =  findViewById(R.id.message_field);
        sendButton = findViewById(R.id.send_button);
        chatListView = findViewById(R.id.chat_listView);
        messageArrayList = new ArrayList<>();
        chatListAdaptor = new ChatListAdaptor(ChatActivity.this , currentUserId, messageArrayList);
        chatListView.setAdapter(chatListAdaptor);
        sendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!messageField.getText().toString().isEmpty()){
                    Message message = new Message();
                    message.setUserId(currentUserId);
                    message.setUsername(currentUsername);
                    message.setBody(messageField.getText().toString());
                    message.setDate(LocalDateTime.now().getHour() +":"+ (LocalDateTime.now().getMinute() >= 10 ? LocalDateTime.now().getMinute():"0"+LocalDateTime.now().getMinute()));
                    message.saveInBackground(new SaveCallback() {
                        @Override
                        public void done(ParseException e) {
                            receiveMessage();
                        }
                    });
                    messageField.setText("");
                }else Toast.makeText(getApplicationContext(), "Fill message field!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void receiveMessage() {
        ParseQuery<Message> messageParseQuery = new ParseQuery<Message>(Message.class);
        messageParseQuery.setLimit(MAX_CHAT_MESSAGES_TO_SHOW);
        messageParseQuery.orderByAscending("createdAt");
        messageParseQuery.findInBackground(new FindCallback<Message>() {
            @Override
            public void done(List<Message> objects, ParseException e) {
                if (e == null){
                    messageArrayList.clear();
                    messageArrayList.addAll(objects);
                    chatListAdaptor.notifyDataSetChanged();
                    chatListView.invalidate();
                }else {
                    Log.e("DATA", "Retrieving data error");
                    e.printStackTrace();
                }
            }
        });
    }

    private void refreshChats(){
        receiveMessage();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.chat_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }


    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.log_out){
            ParseUser.logOutInBackground(new LogOutCallback() {
                @Override
                public void done(ParseException e) {
                    if (e == null){
                        finish();
                        startActivity(new Intent(ChatActivity.this, MainActivity.class));
                    }else {
                        Log.v("USER", "Logout error");
                        e.printStackTrace();
                    }
                }
            });
        }
        return super.onOptionsItemSelected(item);
    }

    private void sendNotification(String sentUser, String messageBody){
        System.out.println("HERE");
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = getString(R.string.channel_name);
            String description = getString(R.string.channel_description);
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
            channel.setDescription(description);
            // Register the channel with the system; you can't change the importance
            // or other notification behaviors after this
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
        Intent intent = new Intent(this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, 0);
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.icon)
                .setContentTitle(sentUser)
                .setContentText(messageBody)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setContentIntent(pendingIntent)
                .setAutoCancel(true);
        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(this);

        // notificationId is a unique int for each notification that you must define
        notificationManager.notify(notificationId, builder.build());
        notificationId += 1;
    }
}