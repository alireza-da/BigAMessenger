package model;

import com.parse.ParseUser;

public class User extends ParseUser {
    private String profilePhoto;
    private String phoneNumber;
}
