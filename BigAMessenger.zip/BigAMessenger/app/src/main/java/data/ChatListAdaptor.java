package data;

import android.content.Context;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.bigamessenger.R;
import com.parse.ParseUser;
import com.squareup.picasso.Picasso;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.List;
import java.util.Spliterator;

import model.Message;

public class ChatListAdaptor extends ArrayAdapter<Message> {
    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    private String userId;
    private RelativeLayout linearLayout;
    public ChatListAdaptor(@NonNull Context context, String givenUserId, List<Message> messages) {
        super(context, 0, messages);
        userId = givenUserId;
    }


    @NonNull
    @Override
    public View getView(int position, View convertView, @NonNull ViewGroup parent) {

        ViewHolder viewHolder = new ViewHolder();
        final Message message = getItem(position);
        final boolean isMe = message.getUserId().equals(userId);
        //if (convertView == null){
            if (isMe){
                convertView = LayoutInflater.from(getContext()).inflate(R.layout.chat_row_sent, parent, false);
            }
            else{
                convertView = LayoutInflater.from(getContext()).inflate(R.layout.chat_row_recieved, parent, false);
            }
            viewHolder.username = convertView.findViewById(R.id.text_message_name);
            viewHolder.body = convertView.findViewById(R.id.text_message_body);
            viewHolder.date = convertView.findViewById(R.id.text_message_time);
            viewHolder.profileImage = convertView.findViewById(R.id.image_message_profile);
            convertView.setTag(viewHolder);

//        }else {
//
//            viewHolder = (ViewHolder) convertView.getTag();
//        }
        //bind
        final ImageView profileImageGra = viewHolder.profileImage;
        Picasso.get().load(getProfileGravatar(message.getUserId())).into(profileImageGra);
        viewHolder.body.setText(message.getBody());
        viewHolder.username.setText(message.getUsername());
        viewHolder.date.setText(message.getDate());
        return convertView ;
    }

    //get gravatar avatar
    private static String getProfileGravatar(final String givenUserId){
        String hex = "";
        try {
            final MessageDigest messageDigest = MessageDigest.getInstance("MD5");
            final byte[] hash = messageDigest.digest(givenUserId.getBytes());
            final BigInteger bigInteger = new BigInteger(hash);
            hex = bigInteger.toString(16);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return "http://www.gravatar.com/avatar/"+hex+"?d=identicon";
    }


    private class ViewHolder{
        public ImageView profileImage;
        public TextView date;
        public TextView body;
        public TextView username;
    }
}
